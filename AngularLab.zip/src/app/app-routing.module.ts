import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import {AllstudentComponent}  from './allstudent/allstudent.component'
import {AddstudentComponent } from './addstudent/addstudent.component'
import {HeaderComponent } from './header/header.component'

const routes: Routes = [
  //{ path:  'allStudents', component:  AllstudentComponent},
  { path:  'addStudents', component:  AddstudentComponent},
  { path: '', component:  HeaderComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
