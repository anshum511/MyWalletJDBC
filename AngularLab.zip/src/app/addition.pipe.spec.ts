import { AdditionPipe } from './addition.pipe';

describe('AdditionPipe', () => {
  it('create an instance', () => {
    const pipe = new AdditionPipe();
    expect(pipe).toBeTruthy();
  });
});
