import { Component, OnInit } from '@angular/core';
import { MathsService } from '../maths.service';
//import data from '../data/data.json';
import employee from '../data/employee.json';
import { injectRenderer2 } from '../../../node_modules/@angular/core/src/render3/view_engine_compatibility';
//import {HttpClient} from '@angular/common/http'; importing http client

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private service: MathsService) { } //private http:HttpClient
  //employees=data
  serv = employee
  showUpdateEmployee= false
  isvalid=false
  ngOnInit() {
    //this.http.get('https://jsonplaceholder.typicode.com/posts').subscribe(abc=>this.serv=abc) to get json file
       // console.log("dta",employee)
  }

  //   ngOnInit() {
  //     //this.service.add();
  //   }
   showDiv=false
     myClickFunction(id,name,salary,department) { 
      //just added console.log which will display the event details in browser on click of the button.
      this.service.print(id,name,salary,department)
     }

  delete(i) {
   // console.log("before delete" ,this.serv)
    this.serv.splice(i,1)
   // console.log("afer Delete" , this.serv)
  }
//  update(i,id){
  //  console.log(id.empDep)

   // this.showUpdateEmployee = true
    //console.log(this.serv.id[i].employee.id='fdgf';

     addEmployee(addingEmp){
  //   //console.log(addEmployee.form.value.empId.length)
  //   //console.log(addEmployee.form.value)
    if(!addingEmp.form.value.empId.length){
       alert('name is required')
       return
     }
  //  // console.log("before Adding " , this.serv)
    this.serv.push(addingEmp.form.value)
  //  // console.log("After Adding  " , this.serv)
   }
   update(i){
     this.isvalid=true
   }

   updateEmployee(emp,emp2){
     emp2.id2=emp.id
     emp2.name2=emp.name
     emp2.salary2=emp.salary
     emp2.department2=emp.department
    }
   
}
  


