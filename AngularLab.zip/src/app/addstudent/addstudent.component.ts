import { Component, OnInit } from '@angular/core';
import employee from '../data/employee.json';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {
  serv = employee
  constructor() { }

  ngOnInit() {
  }

  addEmployee(addEmployee){
    //console.log(addEmployee.form.value.empId.length)
    //console.log(addEmployee.form.value)
     if(!addEmployee.form.value.empId.length){
       alert('name is required')
       return
     }
   // console.log("before Adding " , this.serv)
    this.serv.push(addEmployee.form.value)
   // console.log("After Adding  " , this.serv)
  }

}
