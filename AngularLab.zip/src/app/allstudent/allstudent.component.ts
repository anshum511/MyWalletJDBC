import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allstudent',
  templateUrl: './allstudent.component.html',
  styleUrls: ['./allstudent.component.css']
})
export class AllstudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
