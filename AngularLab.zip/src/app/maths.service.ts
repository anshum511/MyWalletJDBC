import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MathsService {

  //add(a,b){
   // return a+b
 // }
 // multiply(){
   // alert("multiplication")
 // }
  //subtraction(){
    //alert("subtraction")
 // } 
  print(a,b,c,d){
    alert(a+" "+b+" "+c+" "+d)
  }
  constructor() { }
}
