import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AdditionPipe } from './addition.pipe';

// import { HttpClientModule } from '@angular/common/http';
import { AllstudentComponent } from './allstudent/allstudent.component';
import { AddstudentComponent } from './addstudent/addstudent.component'

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AdditionPipe,
    AllstudentComponent,
    AddstudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  //  HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
