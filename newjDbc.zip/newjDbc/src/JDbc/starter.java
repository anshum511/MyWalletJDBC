package JDbc;
import java.util.Scanner;
import java.sql.SQLException;

public class starter {
public static void main(String[] args) throws SQLException {
	Integer eid=1000;
	String name="Raj";
	String city="Pune";
	Integer salary=50000;
	employee emp=new employee();
	emp.setCity(city);
	emp.setEmpId(eid);
	emp.setEmpName(name);
	emp.setSalary(salary);
	empDAO dao= new empDAO();
	dao.addEmployee(emp);
}
}
