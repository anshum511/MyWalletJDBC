package JDbc.copy;

public class employee {
private int empId;
private int salary;
private String empName;
private String City;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}

}
