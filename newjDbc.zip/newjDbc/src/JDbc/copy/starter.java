package JDbc.copy;
import java.util.Scanner;
import java.sql.SQLException;

public class starter {
public static void main(String[] args) throws SQLException {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter employee id, name, salary, city one by one: ");
	int eid=sc.nextInt();
	sc.nextLine();
	String name=sc.nextLine();
	sc.nextInt();
	int salary=sc.nextInt();
	sc.nextLine();
	String city=sc.nextLine();
	employee emp=new employee();
	emp.setCity(city);
	emp.setEmpId(eid);
	emp.setEmpName(name);
	emp.setSalary(salary);
	empDAO dao= new empDAO();
	dao.addEmployee(emp);
}
}
