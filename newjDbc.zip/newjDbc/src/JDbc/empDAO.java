package JDbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class empDAO {
public void addEmployee(employee e) throws SQLException {
	//establish conn
	//drivertype,ipaddress,port,
//statement 
Connection con=null;
	try {//Class.forName("jdbc.oracle.OracleDriver");
 con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
 Statement s=con.createStatement();
 String sql="insert into employee values("+e.getEmpId()+",'"+e.getEmpName()+"',"+e.getSalary()+",'"+e.getCity()+"')";
 //s.executeQuery(s);
 s.executeUpdate(sql);//SQL query should be written as a string 

} catch (SQLException e1) {
	// TODO Auto-generated catch block
	throw e1;
}//xe=name of server, 1521 port no, @localhost ip addr, jdbc"oracle:thin for driver ver4
finally {
	if(con!=null)
		try {
			con.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

}
}
public void getEmployees() {}
	public void updateEmployee() {}
	public void deleteEmployee() {}
}
