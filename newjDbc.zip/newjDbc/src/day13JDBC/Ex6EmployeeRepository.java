//an EmployeeService class which queries on collections provided by EmployeeRepository class for following requirements. Create separate method for each requirement
package day13JDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Ex6EmployeeRepository {
	public static void addEmployee(Ex6Employee employee) {
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		ResultSet resultset=null;
		int queryresult=0;
		try {
			connection = DBConnection.getConnection();
			preparedstatement=connection.prepareStatement("insert into employee values (?,?,?,?,?,?,?,?,?)");
			preparedstatement.setInt(1, employee.getEmployeeId());
			preparedstatement.setString(2, employee.getFirstName());
			preparedstatement.setString(3, employee.getLastName());
			preparedstatement.setString(4, employee.getEmail());
			preparedstatement.setString(5, employee.getPhoneNumber());
			preparedstatement.setString(6, employee.getHireDate());
			preparedstatement.setString(7, employee.getDesignation());
			preparedstatement.setDouble(8, employee.getSalary());
			preparedstatement.setInt(9, employee.getManagerId());
			//preparedstatement.setLong(10, employee.getDepartment());
		
			queryresult=preparedstatement.executeUpdate();
		}
		catch(SQLException sqlException) {
			sqlException.printStackTrace();
		}
		finally
		{
			try 
			{
				if(connection!=null) {
					preparedstatement.close();
					connection.close();
				}
			}
			catch (SQLException sqlException) 
			{
				System.out.println("Error in closing database");

			}
		}		
	}


/*public static List<Ex6Employee> getList() {
	Scanner s=new Scanner(System.in);
//	HashMap<Employee,Department> employee=new HashMap<Employee,Department>();
	List<Ex6Employee> l=new ArrayList<Ex6Employee>();
	Ex6Department d1=new Ex6Department(200,"IT",101);
	Ex6Department d2=new Ex6Department(201,"Finance",111);
	Ex6Department d3=new Ex6Department(202,"Non-Finance",110);
	Ex6Employee e1=new Ex6Employee(101,"Bhawani","Mishra","bhawanimishra@gmail.com","9876543210",LocalDate.parse("2018-08-05"),"Senior Manager",5000.00,115,d1);
	Ex6Employee e2=new Ex6Employee(111,"RobertDowney","Juniors","downeyrobert123@gmail.com","8745987652",LocalDate.parse("2018-08-10"),"Analyst",5000.00,112,d2);
	Ex6Employee e3=new Ex6Employee(110,"Chris","Evans","chris45@gmail.com","8747866903",LocalDate.parse("2018-01-15"),"Manager",5000.00,101,d3);
	Ex6Employee e4=new Ex6Employee(102,"Robert","Pattrick","Hello","9876587654",LocalDate.parse("2017-03-20"),"Analyst",5000.00,101,d1);
	Ex6Employee e5=new Ex6Employee(103,"Glenn","Wells","Hello","8745983215",LocalDate.parse("2017-04-06"),"Analyst",5000.00,110,d3);
	Ex6Employee e6=new Ex6Employee(104,"Sam","Warner","warnersam@gmail.com","8712367656",LocalDate.parse("2016-05-11"),"Analyst",5000.00,110,d3);
	Ex6Employee e7=new Ex6Employee(110,"Billy","Morrison","billy6morrison@gmail.com","8767545657",LocalDate.parse("2017-06-16"),"Analyst",5000.00,110,null);
	l.add(e1);
	l.add(e2);
	l.add(e3);
	l.add(e4);
	l.add(e5);
	l.add(e6);
	l.add(e7);
	return l;
}*/
}


