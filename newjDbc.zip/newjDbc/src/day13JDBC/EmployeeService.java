package day13JDBC;

import day13JDBC.Ex6EmployeeRepository;
import java.util.Scanner;

public class EmployeeService {
	public static void main(String[] args) {
		Ex6Employee emp=new Ex6Employee();

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee details:");
		System.out.println("Employee ID:");
		int empid=sc.nextInt();
		System.out.println("First name:");
		String fname=sc.nextLine();
		sc.nextLine();
		System.out.println("Last name:");
		String lname=sc.nextLine();
		System.out.println("Email:");
		String email=sc.nextLine();
		System.out.println("Phone number:");
		String pno=sc.nextLine();
		System.out.println("Hire date:");
		String hdate=sc.nextLine();
		System.out.println("Designation:");
		String design=sc.nextLine();
		System.out.println("Salary:");
		double salary=sc.nextDouble();
		System.out.println("Manager ID:");
		int mid=sc.nextInt();
		emp.setEmployeeId(empid);
		emp.setDesignation(design);
		emp.setEmail(email);
		emp.setFirstName(fname);
		emp.setLastName(lname);
		emp.setHireDate(hdate);
		emp.setManagerId(mid);
		emp.setPhoneNumber(pno);
		emp.setSalary(salary);
		Ex6EmployeeRepository.addEmployee(emp);
		System.out.println("Values inserted successfully");
	}
	}
	
	
	
	
	/*public static void Departments(List<Ex6Employee> l) {
		List<Ex6Employee> list=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("IT")).collect(Collectors.toList());
		System.out.println("Department:IT");
		list.stream().forEach(e->System.out.println(e.getFirstName()+" "+e.getLastName()));
		System.out.println("Total Number of Employees: "+list.size());
		System.out.println();
		System.out.println("Department:Finance");
		List<Ex6Employee> list2=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("Finance")).collect(Collectors.toList());
		list2.stream().forEach(e->System.out.println(e.getFirstName()+" "+e.getLastName()));
		System.out.println("Total Number of Employees: "+list2.size());
		System.out.println();
		System.out.println("Department:Finance");
		List<Ex6Employee> list3=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("Non-Finance")).collect(Collectors.toList());
		list3.stream().forEach(e->System.out.println(e.getFirstName()+" "+e.getLastName()));
		System.out.println("Total Number of Employees: "+list3.size());
		System.out.println();
		
	}
public static void noDepartment(List<Ex6Employee> l) {
	System.out.println("Employee Having No Department");
	l.stream().filter(i->i.getDepartment()==null).forEach(i->System.out.println(i.getFirstName()+" "+i.getLastName()));
}
public static void Senior(List<Ex6Employee> l) {
	System.out.println("Senior Most Employee");
	l.stream().filter(e->e.getDesignation().equals("Senior Manager")).forEach(i->System.out.println(i.getFirstName()+" "+i.getLastName()));
}
interface findGreatest{
	public String greatest(List<Ex6Employee> a,List<Ex6Employee> b,List<Ex6Employee> c);
}
public static void highestEmployee(List<Ex6Employee> l) {
	List<Ex6Employee> listIT=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("IT")).collect(Collectors.toList());
	System.out.println("Department:IT");
	List<Ex6Employee> listFinance=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("Finance")).collect(Collectors.toList());
	List<Ex6Employee> listNonFinance=l.stream().filter(e->e.getDepartment()!=null && e.getDepartment().getDepartmentName().equals("Non-Finance")).collect(Collectors.toList());
	findGreatest fg=(a,b,c)->{
		if(a.size()>b.size() && a.size()>c.size())
			return a.get(0).getDepartment().getDepartmentName();
		else if(b.size()>a.size() && b.size()>c.size()){
			return b.get(0).getDepartment().getDepartmentName();
		}
		return c.get(0).getDepartment().getDepartmentName();
	};
	System.out.println("Department having maximum employees: "+fg.greatest(listIT,listFinance,listNonFinance));
	
}
public static void getIncresed(List<Ex6Employee> l) {
	l.stream().forEach(e->System.out.println("Name "+e.getFirstName()+" "+e.getLastName()+"\n"+"Salary:"+e.getSalary()+"Incresed Salary"+(0.15*e.getSalary()+e.getSalary())));
}
public static void main(String[] args) {
	List<Ex6Employee> l=Ex6EmployeeRepository.getList();
	EmployeeService.Departments(l);
	EmployeeService.noDepartment(l);
	EmployeeService.Senior(l);
	EmployeeService.highestEmployee(l);
	EmployeeService.getIncresed(l);

}
*/


