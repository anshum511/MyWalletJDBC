package jdbcAssignment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import jdbcAssignment.DBConnection;
public class service {

	public static void updateauthor(String authname,int price) throws SQLException {
		Connection connection=null;
		connection = DBConnection.getConnection();
		Statement s=connection.createStatement();
		String sql="update book bk, author au set bk.price="+price+"where au.fname="+authname;
		s.executeUpdate(sql);
	}
	public static void deleteauthor(int authid) throws SQLException {
		Connection connection=null;
		connection = DBConnection.getConnection();
		Statement s=connection.createStatement();
		String sql="delete table author where authorId="+authid;
		s.executeUpdate(sql);
	}
	public static void addauth(author a1) {
		// TODO Auto-generated method stub
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		ResultSet resultset=null;
		int queryresult=0;
		try {
			connection = DBConnection.getConnection();
			preparedstatement=connection.prepareStatement("insert into author values (?,?,?,?,?)");
			preparedstatement.setInt(1, a1.getAuthorId());
			preparedstatement.setString(2, a1.getFirstName());
			preparedstatement.setString(3, a1.getMiddleName());
			preparedstatement.setString(4, a1.getLastName());
			preparedstatement.setLong(5, a1.getPhoneNo());
			queryresult=preparedstatement.executeUpdate();
		}
		catch(SQLException sqlException) {
			sqlException.printStackTrace();
		}
		finally
		{
			try 
			{
				if(connection!=null) {
					preparedstatement.close();
					connection.close();
				}
			}
			catch (SQLException sqlException) 
			{
				System.out.println("Error in closing database");

			}
		}		
	}
	public static void addbook(book b1) {
		
		Connection connection=null;
		PreparedStatement preparedstatement=null;
		ResultSet resultset=null;
		int queryresult=0;
		try {
			connection = DBConnection.getConnection();
			preparedstatement=connection.prepareStatement("insert into book values (?,?,?)");
			preparedstatement.setString(1, b1.getTitle());
			preparedstatement.setInt(2, b1.getPrice());
			preparedstatement.setInt(3, b1.getIsbn());
			queryresult=preparedstatement.executeUpdate();
		}
		catch(SQLException sqlException) {
			sqlException.printStackTrace();
		}
		finally
		{
			try 
			{
				if(connection!=null) {
					preparedstatement.close();
					connection.close();
				}
			}
			catch (SQLException sqlException) 
			{
				System.out.println("Error in closing database");

			}
		}	
	
	}
	}

