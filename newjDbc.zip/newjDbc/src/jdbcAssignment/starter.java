package jdbcAssignment;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;
public class starter {
	public static void main(String[] args) throws SQLException {
		author aut=new author();
		Scanner sc=new Scanner(System.in);
		System.out.println("Select option:");
		while(true) {
		System.out.println("1:Insert");
		System.out.println("2:Update");
		System.out.println("3:Delete");
		System.out.println("4:Exit");
		int inp=sc.nextInt();
		switch(inp) {
		case(1):		
			author a1=new author();
		book b1=new book();
		System.out.println("Enter author details:");
		System.out.println("ID:");
		sc.nextLine();
		int id = 10000 + new Random().nextInt(90000);
		System.out.println("First name:");
		String fname=sc.nextLine();
		sc.nextLine();
		System.out.println("Middle name:");
		String mname=sc.nextLine();
		System.out.println("Last name:");
		String lname=sc.nextLine();
		System.out.println("Phone no:");
		long pno=sc.nextLong();		
		a1.setAuthorId(id);
		a1.setFirstName(fname);
		a1.setMiddleName(mname);
		a1.setLastName(lname);
		a1.setPhoneNo(pno);
		service.addauth(a1);
		
		System.out.println("Book title:");
		String booktitle=sc.nextLine();
		sc.nextLine();
		System.out.println("Book price:");
		int bookprice=sc.nextInt();
		System.out.println("ISDN no:");
		int isdnno=sc.nextInt();
		b1.setTitle(booktitle);
		b1.setPrice(bookprice);
		b1.setIsbn(isdnno);
		service.addbook(b1);
		System.out.println("values inserted successfully");
		break;
		case(2):
			System.out.println("Enter author name:");
		String authname=sc.nextLine();
		sc.nextInt();
		System.out.println("New price:");
		int price=sc.nextInt();
		service.updateauthor(authname,price);
		break;
		case(3):
			System.out.println("Enter author id:");
		int aid2=sc.nextInt();
		service.deleteauthor(aid2);
		break;
		case(4):
			System.out.println("Exiting.....");
			sc.close();
		System.exit(0);
		}
	}
}
}
