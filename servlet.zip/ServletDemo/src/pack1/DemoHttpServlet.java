package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/http")
public class DemoHttpServlet extends HttpServlet{

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw=res.getWriter();
	//	pw.println(Calendar.getInstance().getTime());
	String username=req.getParameter("uname");
	String password=req.getParameter("pass");
	
	if(username.equals("admin") && password.equals("admin")) {
	pw.println("Authenticated \n");
	pw.println("Username: "+username+" Password: "+password);
	}
	else {
		pw.println("Invalid Credentials");
	}
	}
	
	
}
