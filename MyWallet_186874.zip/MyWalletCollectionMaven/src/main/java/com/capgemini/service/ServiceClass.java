//Service class to validate inputs
package com.capgemini.service;
 import com.capgemini.bean.Customer;
import com.capgemini.dao.DaoClass;
import com.capgemini.dao.DaoInterface;
public class ServiceClass implements ServiceInterface{
public static String mobilenovalidator ="[1-9]{1}[0-9]{9}"; //accepts 10 digits number
public static String namevalidator = "[A-Z]*[a-z]*";//((\\s)))+[A-Z]*[a-z]*$     use the commented regex function for full name
public static boolean stringValidator(String data,String pattern) {
	return data.matches(pattern); //matches input data with pattern 
}


static DaoInterface dao=new DaoClass();
public static boolean createCustomer(Customer c) {
	boolean result=dao.createCustomer(c);
return result;
}
@Override
public void getAccountDetails(long accNo) {
	// TODO Auto-generated method stub
	dao.getAccountDetails(accNo);
}
@Override
public void deposit(long accnotemp, double balance1) {
	// TODO Auto-generated method stub
	dao.deposit(accnotemp, balance1);
	/*return d;*/
}
@Override
public void withdraw(long accnotemp3,double balance2) {
	// TODO Auto-generated method stub
	dao.withdraw(accnotemp3,balance2);
	/*return w;*/
}
@Override
public void transfer(long accnotemp2, long accnotemp4, double balance3) {
	// TODO Auto-generated method stub
	dao.transfer(accnotemp2, accnotemp4, balance3);
}
@Override
public void printTransaction() {
	dao.printTransaction();
	// TODO Auto-generated method stub
	
}

}