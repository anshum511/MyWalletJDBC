package JunitTest;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.jupiter.api.Test;

import com.capgemini.bean.Customer;
import com.capgemini.dao.DaoClass;
import com.capgemini.dao.DaoInterface;

class WalletJunitTest {
	static DaoInterface dao=new DaoClass();
	static Customer c1=new Customer();
	static Map<Long,Customer> customers=new HashMap<Long,Customer>();
	DaoClass da1=new DaoClass();
	String testname="bhawani";
	String phonenumber="7692812835";
	String accountnumber="8702913845";
	String testbalance="30000";
	@Test
	void test() {
		long accNo = 8702913845l;
		if(customers.containsKey(accNo)) {
			Set<Entry<Long,Customer>> set=customers.entrySet();     
			Iterator<Entry<Long,Customer>> itr=set.iterator();
			while(itr.hasNext()) {
				Map.Entry<Long, Customer> entry=(Map.Entry<Long, Customer>) itr.next();
				if(entry.getKey().equals(accNo)) {
					Customer c=entry.getValue();
					assertEquals(testname, c1.getName());
					assertEquals(phonenumber, c1.getPhoneNo());
					assertEquals(accountnumber, c1.getAccNo());
					assertEquals(testbalance, c1.getBalance());
				}
			}
		}

	}

}
