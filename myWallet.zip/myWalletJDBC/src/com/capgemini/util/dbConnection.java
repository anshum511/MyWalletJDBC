package com.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {

	private static String user = "system";
	private static String password = "root";
	private static String url="jdbc:oracle:thin:@localhost:1521:xe";


	
	public static Connection getConnection() throws SQLException {
		
		return DriverManager.getConnection(url,user,password);
	}
}
