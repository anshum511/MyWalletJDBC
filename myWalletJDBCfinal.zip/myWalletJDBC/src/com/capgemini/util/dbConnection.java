package com.capgemini.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {

	private static String user = "root";
	private static String password = "root";
	private static String url="jdbc:mysql://localhost:3306/db";//"jdbc:oracle:thin:@localhost:1521:orcl";


	
	public static Connection getConnection() throws SQLException {
		
		return DriverManager.getConnection(url,user,password);
	}
}
