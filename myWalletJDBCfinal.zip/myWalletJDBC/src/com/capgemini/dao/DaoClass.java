//DAO class to declare methods
package com.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.capgemini.bean.Customer;
import com.capgemini.exception.CustomerException;
import com.capgemini.util.dbConnection;

public class DaoClass implements DaoInterface {
	static Customer c1 = new Customer();
	static Map<Long, Customer> customers = new HashMap<Long, Customer>(); // declaring hash map to store values of
																			// customer
	ArrayList<String> mylist = new ArrayList<String>(); // array for transactions

	
	/*************************************************************
	 * method to set account details ()
	 * 
	 * @throws Exception
	 * @see com.capgemini.dao.DaoInterface#createCustomer(customer) method
	 *      name:crateCustomer return type:boolean argument type:Customer
	 */
	
	public boolean createCustomer(Customer customer) throws CustomerException {
		Connection connection = null;

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		int queryResult = 0;
		try {
			connection = dbConnection.getConnection();
			preparedStatement = connection.prepareStatement("insert into customer values (?,?,?,?)");

			preparedStatement.setLong(1, customer.getAccNo());
			preparedStatement.setString(2, customer.getName());
			preparedStatement.setDouble(3, customer.getBalance());
			preparedStatement.setLong(4, customer.getPhoneNo());

			queryResult = preparedStatement.executeUpdate();

			if (queryResult == 0) {
				throw new CustomerException("Inserting employee details failed ");
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new CustomerException("Tehnical problem occured");
		}

		finally {
			try {
				if (connection != null) {
					preparedStatement.close();
					connection.close();
				}
			} catch (SQLException sqlException) {
				throw new CustomerException("Error in closing db connection");

			}
		}
		return true;

	}

	
	/*************************************************************
	 * method to get account details ()
	 * 
	 * @throws Exception
	 * @see com.capgemini.dao.DaoInterface#getAccountDetails(long) method
	 *      name:getAccountDetails return type:double argument type:long
	 */
	
	@Override
	public void getAccountDetails(long accNo) throws CustomerException {
		Connection con = null;

		PreparedStatement ps = null;
		ResultSet resultset = null;

		List<Customer> cstList = new ArrayList<>();
		try {
			con = dbConnection.getConnection();
			ps = con.prepareStatement("select * from customer where accNo=" + accNo);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				System.out.println(resultset.getLong("accNo"));
				System.out.println(resultset.getString("name"));
				System.out.println(resultset.getDouble("balance"));
				System.out.println(resultset.getLong("phoneNo"));
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new CustomerException("Tehnical problem occured. Refer log");

		}

		finally {
			try {
				if (con != null) {
					resultset.close();
					ps.close();
					con.close();
				}
			} catch (SQLException e) {
				throw new CustomerException("Error in closing db connection");

			}
		}
	}

	
	/************************************************************
	 * method to deposit ()
	 * 
	 * @see com.capgemini.dao.DaoInterface#deposit(long,double) method name:deposit
	 *      return type:void argument type:long,double
	 */
	
	@Override
	public void deposit(long accnotemp, double balance1) throws CustomerException {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet resultset = null;

		try {
			con = dbConnection.getConnection();
			ps = con.prepareStatement("update customer set balance=balance+" + balance1 + " where accNo=" + accnotemp);
			ps.executeUpdate();

			ps = con.prepareStatement("select balance from customer where accNo=" + accnotemp);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				System.out.println("Updated balance=" + resultset.getDouble("balance"));
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new CustomerException("Tehnical problem occured. Refer log");

		}

		finally {
			try {
				if (con != null) {
					resultset.close();
					ps.close();
					con.close();
				}
			} catch (SQLException e) {
				throw new CustomerException("Error in closing db connection");

			}
		}

		mylist.add(balance1 + " Deposited to " + accnotemp);
	}

	
	/************************************************************
	 * method to withdraw ()
	 * 
	 * @see com.capgemini.dao.DaoInterface#withdraw(long,double) method
	 *      name:withdraw return type:void argument type:long,double
	 */
	
	@Override
	public void withdraw(long accnotemp3, double balance2) throws CustomerException {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet resultset = null;

		try {
			con = dbConnection.getConnection();
			ps = con.prepareStatement("update customer set balance=balance-" + balance2 + " where accNo=" + accnotemp3);
			ps.executeUpdate();

			ps = con.prepareStatement("select balance from customer where accNo=" + accnotemp3);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				System.out.println("Balance after withdrawn=" + resultset.getDouble("balance"));
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new CustomerException("Tehnical problem occured. Refer log");

		}

		finally {
			try {
				if (con != null) {
					resultset.close();
					ps.close();
					con.close();
				}
			} catch (SQLException e) {
				throw new CustomerException("Error in closing db connection");

			}
		}

		mylist.add(balance2 + " Withdrawn from " + accnotemp3);
	}

	
	/************************************************************
	 * method to transfer ()
	 * 
	 * @see com.capgemini.dao.DaoInterface#transfer(long,long,double) method
	 *      name:transfer return type:void argument type:long,long,double
	 */
	
	@Override
	public void transfer(long accnotemp2, long accnotemp4, double balance3) throws CustomerException {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet resultset = null;

		try {
			con = dbConnection.getConnection();
			ps = con.prepareStatement("update customer set balance=balance+" + balance3 + " where accNo=" + accnotemp2);
			ps.executeUpdate();

			ps = con.prepareStatement("update customer set balance=balance-" + balance3 + " where accNo=" + accnotemp4);
			ps.executeUpdate();

			ps = con.prepareStatement("select balance from customer where accNo=" + accnotemp2);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				System.out.println("Receiver balance after transfer=" + resultset.getDouble("balance"));
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new CustomerException("Tehnical problem occured. Refer log");

		}

		finally {
			try {
				if (con != null) {
					resultset.close();
					ps.close();
					con.close();
				}
			} catch (SQLException e) {
				throw new CustomerException("Error in closing db connection");

			}
		}

		mylist.add(balance3 + " Transferred from " + accnotemp4 + " to " + accnotemp2);
	}

	
	/************************************************************
	 * method to printTransaction ()
	 * 
	 * @see com.capgemini.dao.DaoInterface#printTransaction() method
	 *      name:printTransaction return type:void argument type:void
	 */
	
	@Override
	public void printTransaction() throws CustomerException {
		for (String string : mylist) {
			System.out.println(string);
		}
	}
}
